#include "MySQLConnectorUE5Plugin.h"

DEFINE_LOG_CATEGORY(LogMySQL_Database)

IMPLEMENT_MODULE(FDefaultGameModuleImpl, MySQLConnectorUE5Plugin)
