#pragma once

#include "CoreUObject.h"

//#include "SQLiteDatabase.h"
//#include "SQLiteBlueprintFunctionLibrary.h"
//#include "SQLiteBlueprintNodes.h"


DECLARE_LOG_CATEGORY_EXTERN(LogMySQL_Database, All, All);